## Changelog (latest patch listed first)

### 2.0.5
* Update for Valheim 0.216.9

### 2.0.4
* Mistlands update

### 2.0.1/2.0.2/2.0.3
* Update ServerSync internally.

### 2.0.0
* `Note:` You will need to regenerate your configuration file. The file name has changed to fall in line with my other mods. It is now `Azumatt.PvPAlways.cfg`
* Update ServerSync
* Ward compatibility. This just means that this mod will not attempt to enforce PvP in wards. WardIsLove & BetterWards
  will still enforce PvP in wards if you tell them to.

### 1.0.0

* Initial re-release.